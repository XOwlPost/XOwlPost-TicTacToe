#!/usr/bin/env bash
node ${BASH_SOURCE%/*}/src/main.js $*